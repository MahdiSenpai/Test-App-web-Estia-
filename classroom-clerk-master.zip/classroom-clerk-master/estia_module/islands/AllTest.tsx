import { useContext, useState } from "preact/hooks";
import { HomeContext } from "../context/HomeContext.ts";

export default function AllTest() {
  const { statee, setStatee } = useContext(HomeContext);
  
  return (
    <div>
      fallut
    </div>
  );
}
