

export default function Moreinfo() {
  return (
    <div>
      <p>voici plus d'info sur la cohorte (faire apelle BD)</p>
    </div>
    
  );
}

