

export default function Home() {
  return (
    <div>
      <h1>ceci est la page 1</h1>
      <a href="/">go home</a>
    </div>
  );
}
